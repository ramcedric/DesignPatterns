package adapter2;

public interface AudioPlayer {
    void playAudio(String fileName);
}