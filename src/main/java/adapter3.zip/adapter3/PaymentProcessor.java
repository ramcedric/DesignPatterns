package adapter3;

public interface PaymentProcessor {
    void processPayment(String amount);
}