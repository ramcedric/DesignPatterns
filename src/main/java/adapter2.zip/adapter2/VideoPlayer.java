package adapter2;

public interface VideoPlayer {
    void playVideo(String fileName);
}

