package adapter2;

public interface MediaPlayer {
    void play(String mediaType, String fileName);
}