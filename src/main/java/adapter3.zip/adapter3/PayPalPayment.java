package adapter3;

public class PayPalPayment {
    public void makePayment(String amount) {
        System.out.println("Processing PayPal payment of $" + amount);
    }
}
